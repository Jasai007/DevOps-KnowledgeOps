// Simple Auth Handler - Works without Cognito for testing
exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE,PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  try {
    console.log('Auth request received:', JSON.stringify(event, null, 2));

    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS request');
      return {
        statusCode: 200,
        headers,
        body: '',
      };
    }

    if (!event.body) {
      console.log('No body in request');
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ success: false, error: 'Request body is required' }),
      };
    }

    const request = JSON.parse(event.body);
    console.log('Parsed request:', request);

    // Handle signin action
    if (request.action === 'signin') {
      console.log('Processing signin request');
      
      // For demo purposes, accept any email/password combination
      if (request.username && request.password) {
        const mockResponse = {
          success: true,
          data: {
            success: true,
            accessToken: 'mock-access-token-' + Date.now(),
            idToken: 'mock-id-token-' + Date.now(),
            refreshToken: 'mock-refresh-token-' + Date.now(),
            user: {
              email: request.username,
              username: request.username,
              role: 'user'
            },
            message: 'Login successful (demo mode)'
          }
        };
        
        console.log('Returning success response:', mockResponse);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(mockResponse),
        };
      } else {
        console.log('Missing username or password');
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ success: false, error: 'Username and password are required' }),
        };
      }
    }

    // Handle other actions
    if (request.action === 'signup') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, message: 'Signup successful (demo mode)' }),
      };
    }

    console.log('Unknown action:', request.action);
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: 'Invalid action' }),
    };

  } catch (error) {
    console.error('Auth handler error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, error: 'Internal server error: ' + error.message }),
    };
  }
};