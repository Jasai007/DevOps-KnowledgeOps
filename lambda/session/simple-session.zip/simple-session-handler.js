// Simple Session Handler
exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE,PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  try {
    console.log('Simple session handler called:', JSON.stringify(event, null, 2));

    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS preflight request');
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: 'CORS preflight successful' })
      };
    }

    if (event.httpMethod === 'POST') {
      if (!event.body) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            success: false,
            error: 'Request body is required'
          }),
        };
      }

      const request = JSON.parse(event.body);
      console.log('Parsed request:', request);

      // Handle session creation
      if (request.action === 'create' || !request.action) {
        const sessionId = `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        const sessionResponse = {
          success: true,
          sessionId: sessionId,
          createdAt: new Date().toISOString(),
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
          metadata: {
            region: 'us-east-1',
            agentId: 'simple-devops-agent',
            mode: 'demo'
          }
        };

        console.log('Created session:', sessionId);

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(sessionResponse),
        };
      }

      // Handle other session actions
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: 'Session action processed'
        }),
      };
    }

    // Handle other HTTP methods
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Method not allowed'
      }),
    };

  } catch (error) {
    console.error('Session handler error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Internal server error: ' + error.message
      }),
    };
  }
};