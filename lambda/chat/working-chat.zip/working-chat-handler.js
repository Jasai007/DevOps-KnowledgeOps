// Working Chat Handler - Complete and Tested
exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE,PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  try {
    console.log('Working chat handler called:', JSON.stringify(event, null, 2));

    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS preflight request');
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: 'CORS preflight successful' })
      };
    }

    if (event.httpMethod === 'POST') {
      if (!event.body) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            success: false,
            error: 'Request body is required'
          }),
        };
      }

      const request = JSON.parse(event.body);
      console.log('Parsed request:', request);

      if (!request.message) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            success: false,
            error: 'Message is required'
          }),
        };
      }

      // Generate session ID if not provided
      const sessionId = request.sessionId || `session-${Date.now()}`;
      
      console.log('Processing message:', request.message);

      // Generate DevOps response
      const response = generateDevOpsResponse(request.message);

      const chatResponse = {
        success: true,
        response: response,
        sessionId: sessionId,
        metadata: {
          responseTime: Date.now(),
          agentId: 'working-devops-agent',
          region: 'us-east-1',
          messageCount: 1,
          memoryEnabled: true,
          mode: 'production'
        }
      };

      console.log('Returning response:', {
        success: chatResponse.success,
        responseLength: chatResponse.response.length,
        sessionId: chatResponse.sessionId
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(chatResponse),
      };
    }

    // Handle other HTTP methods
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Method not allowed'
      }),
    };

  } catch (error) {
    console.error('Working chat handler error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Internal server error: ' + error.message
      }),
    };
  }
};

function generateDevOpsResponse(message) {
  const lowerMessage = message.toLowerCase();
  
  // Docker responses
  if (lowerMessage.includes('docker') || lowerMessage.includes('container')) {
    return `🐳 **Docker & Containerization Help**

Here's how I can help you with Docker:

**Dockerfile Best Practices:**
\`\`\`dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
USER node
CMD ["npm", "start"]
\`\`\`

**Key Docker Concepts:**
• **Images**: Read-only templates for containers
• **Containers**: Running instances of images
• **Volumes**: Persistent data storage
• **Networks**: Container communication

**Common Commands:**
\`\`\`bash
docker build -t myapp .
docker run -p 3000:3000 myapp
docker ps
docker logs <container-id>
\`\`\`

**Optimization Tips:**
• Use multi-stage builds
• Minimize layer count
• Use .dockerignore
• Run as non-root user

What specific Docker challenge are you facing?`;
  }

  // Kubernetes responses
  if (lowerMessage.includes('kubernetes') || lowerMessage.includes('k8s')) {
    return `☸️ **Kubernetes Orchestration Help**

**Basic Kubernetes Deployment:**
\`\`\`yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: web-app
  template:
    metadata:
      labels:
        app: web-app
    spec:
      containers:
      - name: web-app
        image: myapp:latest
        ports:
        - containerPort: 3000
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "200m"
\`\`\`

**Essential Kubernetes Objects:**
• **Pods**: Smallest deployable units
• **Deployments**: Manage pod replicas
• **Services**: Network access to pods
• **ConfigMaps**: Configuration data
• **Secrets**: Sensitive information

**Useful Commands:**
\`\`\`bash
kubectl get pods
kubectl describe pod <pod-name>
kubectl logs <pod-name>
kubectl apply -f deployment.yaml
\`\`\`

What Kubernetes topic would you like to explore?`;
  }

  // CI/CD responses
  if (lowerMessage.includes('ci/cd') || lowerMessage.includes('pipeline') || lowerMessage.includes('github actions')) {
    return `🚀 **CI/CD Pipeline Help**

**GitHub Actions Example:**
\`\`\`yaml
name: CI/CD Pipeline
on:
  push:
    branches: [main]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-node@v3
      with:
        node-version: '18'
    - run: npm ci
    - run: npm test
    - run: npm run build
  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - name: Deploy
      run: echo "Deploying to production"
\`\`\`

**CI/CD Best Practices:**
• **Automated Testing**: Unit, integration, e2e tests
• **Code Quality**: Linting, security scans
• **Artifact Management**: Build once, deploy many
• **Environment Parity**: Consistent environments
• **Rollback Strategy**: Quick recovery plans

**Popular Tools:**
• GitHub Actions, GitLab CI, Jenkins
• Docker for containerization
• Kubernetes for orchestration

What part of your CI/CD pipeline needs help?`;
  }

  // Infrastructure as Code
  if (lowerMessage.includes('terraform') || lowerMessage.includes('infrastructure') || lowerMessage.includes('iac')) {
    return `🏗️ **Infrastructure as Code Help**

**Terraform Example:**
\`\`\`hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1d0"
  instance_type = "t3.micro"
  
  tags = {
    Name = "WebServer"
    Environment = "production"
  }
}

resource "aws_security_group" "web" {
  name = "web-sg"
  
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
\`\`\`

**IaC Benefits:**
• **Version Control**: Track infrastructure changes
• **Reproducibility**: Consistent environments
• **Automation**: Reduce manual errors
• **Documentation**: Code as documentation

**Best Practices:**
• Use modules for reusability
• Implement remote state
• Plan before apply
• Use workspaces for environments

**Tools Comparison:**
• **Terraform**: Multi-cloud, declarative
• **CloudFormation**: AWS-native
• **Pulumi**: Programming languages

What infrastructure challenge are you working on?`;
  }

  // Monitoring
  if (lowerMessage.includes('monitor') || lowerMessage.includes('observ') || lowerMessage.includes('prometheus')) {
    return `📊 **Monitoring & Observability Help**

**The Three Pillars:**
1. **Metrics**: Quantitative measurements (CPU, memory, response time)
2. **Logs**: Event records and error messages  
3. **Traces**: Request flow through distributed systems

**Prometheus + Grafana Stack:**
\`\`\`yaml
# Prometheus config
global:
  scrape_interval: 15s
scrape_configs:
  - job_name: 'web-app'
    static_configs:
    - targets: ['localhost:3000']
\`\`\`

**Key Metrics to Monitor:**
• **Application**: Response time, error rate, throughput
• **Infrastructure**: CPU, memory, disk, network
• **Business**: User actions, conversions

**Alerting Best Practices:**
• Alert on symptoms, not causes
• Avoid alert fatigue
• Use escalation policies
• Document runbooks

**Popular Tools:**
• **Metrics**: Prometheus, DataDog, New Relic
• **Logs**: ELK Stack, Splunk
• **APM**: Jaeger, Zipkin

What monitoring aspect needs attention?`;
  }

  // Security
  if (lowerMessage.includes('security') || lowerMessage.includes('devsecops')) {
    return `🔒 **DevSecOps & Security Help**

**Security in CI/CD:**
1. **SAST**: Static code analysis (SonarQube)
2. **DAST**: Dynamic testing (OWASP ZAP)
3. **Container Scanning**: Image vulnerabilities (Trivy)
4. **Dependency Scanning**: Package vulnerabilities
5. **Infrastructure Scanning**: IaC security (Checkov)

**Container Security:**
\`\`\`dockerfile
# Use minimal base images
FROM alpine:3.18

# Don't run as root
RUN addgroup -g 1001 -S appuser && \\
    adduser -S appuser -u 1001
USER appuser

# Use specific versions
COPY package*.json ./
RUN npm ci --only=production
\`\`\`

**Kubernetes Security:**
• Network policies for segmentation
• Pod Security Standards
• RBAC for access control
• Secrets management
• Regular updates

**Best Practices:**
• Shift-left security
• Principle of least privilege
• Regular security audits
• Incident response plans

What security challenge are you addressing?`;
  }

  // General greeting
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('help')) {
    return `👋 **Hello! I'm your DevOps Expert Assistant**

I can help you with:

🐳 **Containerization**: Docker, Kubernetes, orchestration
🚀 **CI/CD**: Pipelines, automation, deployment strategies
🏗️ **Infrastructure**: Terraform, CloudFormation, IaC
📊 **Monitoring**: Prometheus, Grafana, observability
🔒 **Security**: DevSecOps, container security, compliance
☁️ **Cloud**: AWS, Azure, GCP services and migration
🔧 **Troubleshooting**: Debugging, performance, optimization

**Popular Questions:**
• "How do I optimize my Dockerfile?"
• "Help me set up a CI/CD pipeline"
• "What's the best way to monitor applications?"
• "How do I deploy to Kubernetes?"
• "Show me Terraform best practices"

What DevOps challenge can I help you solve today?`;
  }

  // Default response
  return `🤖 **DevOps Assistant Ready to Help!**

I specialize in DevOps practices and can provide guidance on:

• **Containerization** (Docker, Kubernetes)
• **CI/CD Pipelines** (GitHub Actions, Jenkins)
• **Infrastructure as Code** (Terraform, CloudFormation)
• **Monitoring & Observability** (Prometheus, Grafana)
• **Security & Compliance** (DevSecOps practices)
• **Cloud Platforms** (AWS, Azure, GCP)
• **Troubleshooting** (Debugging, optimization)

**Try asking:**
- "Help me with Docker containers"
- "How do I set up monitoring?"
- "Show me CI/CD best practices"
- "What's the best way to deploy applications?"

I'm ready to provide detailed, practical DevOps guidance! What would you like to work on?`;
}