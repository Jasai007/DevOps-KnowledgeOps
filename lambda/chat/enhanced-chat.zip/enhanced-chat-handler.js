// Enhanced Chat Handler - Proper DevOps Assistant Responses
exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE,PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  try {
    console.log('Enhanced chat handler called:', JSON.stringify(event, null, 2));

    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS preflight request');
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: 'CORS preflight successful' })
      };
    }

    if (event.httpMethod === 'POST') {
      if (!event.body) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            success: false,
            error: 'Request body is required'
          }),
        };
      }

      const request = JSON.parse(event.body);
      console.log('Parsed request:', request);

      if (!request.message) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            success: false,
            error: 'Message is required'
          }),
        };
      }

      // Generate session ID if not provided
      const sessionId = request.sessionId || `session-${Date.now()}`;
      
      console.log('Processing message:', request.message);

      // Enhanced DevOps Assistant Logic
      const response = generateDevOpsResponse(request.message);

      const chatResponse = {
        success: true,
        response: response,
        sessionId: sessionId,
        metadata: {
          responseTime: Date.now(),
          agentId: 'enhanced-devops-agent',
          region: 'us-east-1',
          messageCount: 1,
          memoryEnabled: true,
          mode: 'enhanced'
        }
      };

      console.log('Returning enhanced response:', {
        success: chatResponse.success,
        responseLength: chatResponse.response.length,
        sessionId: chatResponse.sessionId
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(chatResponse),
      };
    }

    // Handle other HTTP methods
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Method not allowed'
      }),
    };

  } catch (error) {
    console.error('Enhanced chat handler error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Internal server error: ' + error.message
      }),
    };
  }
};

function generateDevOpsResponse(message) {
  const lowerMessage = message.toLowerCase();
  
  // Docker-related responses
  if (lowerMessage.includes('docker') || lowerMessage.includes('container')) {
    if (lowerMessage.includes('dockerfile') || lowerMessage.includes('build')) {
      return `Here's a best practice Dockerfile structure:

\`\`\`dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
USER node
CMD ["npm", "start"]
\`\`\`

Key practices:
• Use specific base image versions
• Copy package files first for better layer caching
• Use multi-stage builds for smaller images
• Run as non-root user for security
• Use .dockerignore to exclude unnecessary files

Would you like me to explain any specific part or help with optimization?`;
    }
    
    if (lowerMessage.includes('compose') || lowerMessage.includes('orchestrat')) {
      return `Docker Compose is great for local development and simple deployments. Here's a typical setup:

\`\`\`yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    depends_on:
      - db
  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=myapp
      - POSTGRES_PASSWORD=secret
    volumes:
      - postgres_data:/var/lib/postgresql/data
volumes:
  postgres_data:
\`\`\`

For production, consider Kubernetes or Docker Swarm for better scalability and management.`;
    }
    
    return `Docker is essential for modern DevOps! Here are key concepts:

**Containerization Benefits:**
• Consistent environments across dev/staging/prod
• Faster deployments and scaling
• Better resource utilization
• Simplified dependency management

**Best Practices:**
• Keep images small and secure
• Use multi-stage builds
• Implement health checks
• Follow the principle of one process per container

What specific Docker challenge are you facing? I can help with Dockerfiles, networking, volumes, or deployment strategies.`;
  }

  // Kubernetes-related responses
  if (lowerMessage.includes('kubernetes') || lowerMessage.includes('k8s')) {
    if (lowerMessage.includes('deployment') || lowerMessage.includes('deploy')) {
      return `Here's a production-ready Kubernetes deployment:

\`\`\`yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web-app
spec:
  replicas: 3
  selector:
    matchLabels:
      app: web-app
  template:
    metadata:
      labels:
        app: web-app
    spec:
      containers:
      - name: web-app
        image: myapp:v1.2.3
        ports:
        - containerPort: 3000
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "200m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
\`\`\`

Key elements: resource limits, health checks, and proper labeling for service discovery.`;
    }
    
    if (lowerMessage.includes('service') || lowerMessage.includes('ingress')) {
      return `Kubernetes networking essentials:

**Service (ClusterIP):**
\`\`\`yaml
apiVersion: v1
kind: Service
metadata:
  name: web-app-service
spec:
  selector:
    app: web-app
  ports:
  - port: 80
    targetPort: 3000
\`\`\`

**Ingress for external access:**
\`\`\`yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: web-app-ingress
spec:
  rules:
  - host: myapp.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: web-app-service
            port:
              number: 80
\`\`\`

Don't forget to configure your ingress controller (nginx, traefik, etc.)!`;
    }
    
    return `Kubernetes orchestrates containers at scale! Key concepts:

**Core Components:**
• Pods: Smallest deployable units
• Deployments: Manage pod replicas
• Services: Network access to pods
• ConfigMaps/Secrets: Configuration management

**Production Considerations:**
• Resource requests and limits
• Health checks (liveness/readiness probes)
• Horizontal Pod Autoscaling (HPA)
• Network policies for security
• Persistent volumes for stateful apps

What aspect of Kubernetes would you like to explore? Deployments, networking, storage, or monitoring?`;
  }

  // CI/CD Pipeline responses
  if (lowerMessage.includes('ci/cd') || lowerMessage.includes('pipeline') || lowerMessage.includes('jenkins') || lowerMessage.includes('github actions')) {
    if (lowerMessage.includes('github') || lowerMessage.includes('actions')) {
      return `GitHub Actions CI/CD pipeline example:

\`\`\`yaml
name: CI/CD Pipeline
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    - run: npm ci
    - run: npm test
    - run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - name: Deploy to production
      run: |
        echo "Deploying to production..."
        # Add your deployment commands here
\`\`\`

**Best Practices:**
• Separate test and deploy jobs
• Use caching for dependencies
• Implement proper secrets management
• Add security scanning steps`;
    }
    
    return `CI/CD is crucial for reliable software delivery! Here's a typical pipeline:

**Continuous Integration:**
1. Code commit triggers pipeline
2. Run automated tests (unit, integration)
3. Build artifacts (Docker images, binaries)
4. Security and quality scans
5. Store artifacts in registry

**Continuous Deployment:**
1. Deploy to staging environment
2. Run smoke tests
3. Deploy to production (with approval gates)
4. Monitor deployment health
5. Rollback capability if issues arise

**Popular Tools:**
• GitHub Actions, GitLab CI, Jenkins
• AWS CodePipeline, Azure DevOps
• CircleCI, Travis CI

**Key Principles:**
• Fail fast with comprehensive testing
• Immutable deployments
• Blue-green or canary deployments
• Infrastructure as Code

What's your current CI/CD setup? I can help optimize your pipeline!`;
  }

  // Infrastructure as Code responses
  if (lowerMessage.includes('terraform') || lowerMessage.includes('infrastructure') || lowerMessage.includes('iac') || lowerMessage.includes('cloudformation')) {
    if (lowerMessage.includes('terraform')) {
      return `Terraform Infrastructure as Code example:

\`\`\`hcl
# Provider configuration
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

# VPC and networking
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
  
  tags = {
    Name = "main-vpc"
  }
}

resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "us-west-2a"
  map_public_ip_on_launch = true
  
  tags = {
    Name = "public-subnet"
  }
}

# Security group
resource "aws_security_group" "web" {
  name_prefix = "web-"
  vpc_id      = aws_vpc.main.id
  
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
\`\`\`

**Best Practices:**
• Use modules for reusability
• Implement remote state with locking
• Use workspaces for environments
• Plan before apply, always!`;
    }
    
    return `Infrastructure as Code (IaC) is essential for scalable, repeatable deployments!

**Key Benefits:**
• Version control for infrastructure
• Consistent environments
• Faster provisioning and scaling
• Reduced human error
• Better disaster recovery

**Popular Tools:**
• **Terraform**: Multi-cloud, declarative
• **AWS CloudFormation**: AWS-native
• **Pulumi**: Programming language-based
• **Ansible**: Configuration management + provisioning

**Best Practices:**
• Use version control for all IaC code
• Implement proper state management
• Use modules/templates for reusability
• Test infrastructure changes in staging
• Implement proper access controls

**Typical Workflow:**
1. Write infrastructure code
2. Plan changes (terraform plan)
3. Review and approve
4. Apply changes
5. Monitor and validate

Which IaC tool are you using or considering? I can provide specific guidance!`;
  }

  // Monitoring and Observability
  if (lowerMessage.includes('monitor') || lowerMessage.includes('observ') || lowerMessage.includes('prometheus') || lowerMessage.includes('grafana')) {
    return `Monitoring and Observability are critical for production systems!

**The Three Pillars:**
1. **Metrics**: Quantitative data (CPU, memory, response times)
2. **Logs**: Event records and error messages
3. **Traces**: Request flow through distributed systems

**Popular Stack (Prometheus + Grafana):**
\`\`\`yaml
# Prometheus config
global:
  scrape_interval: 15s
scrape_configs:
  - job_name: 'kubernetes-pods'
    kubernetes_sd_configs:
    - role: pod
    relabel_configs:
    - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
      action: keep
      regex: true
\`\`\`

**Key Metrics to Monitor:**
• **Application**: Response time, error rate, throughput
• **Infrastructure**: CPU, memory, disk, network
• **Business**: User signups, transactions, revenue

**Alerting Best Practices:**
• Alert on symptoms, not causes
• Use SLIs (Service Level Indicators)
• Implement escalation policies
• Avoid alert fatigue

**Tools by Category:**
• **Metrics**: Prometheus, DataDog, New Relic
• **Logs**: ELK Stack, Splunk, Fluentd
• **APM**: Jaeger, Zipkin, AWS X-Ray

What monitoring challenges are you facing? I can help with setup, alerting, or dashboard design!`;
  }

  // Security and DevSecOps
  if (lowerMessage.includes('security') || lowerMessage.includes('devsecops') || lowerMessage.includes('vulnerab')) {
    return `DevSecOps integrates security throughout the development lifecycle!

**Security in CI/CD Pipeline:**
1. **Code Analysis**: SAST tools (SonarQube, Checkmarx)
2. **Dependency Scanning**: Check for vulnerable packages
3. **Container Scanning**: Scan Docker images (Trivy, Clair)
4. **Infrastructure Scanning**: IaC security (Checkov, tfsec)
5. **Runtime Protection**: RASP, WAF, monitoring

**Container Security:**
\`\`\`dockerfile
# Use minimal base images
FROM alpine:3.18

# Don't run as root
RUN addgroup -g 1001 -S nodejs && adduser -S nodejs -u 1001
USER nodejs

# Use specific versions
COPY package*.json ./
RUN npm ci --only=production && npm cache clean --force
\`\`\`

**Kubernetes Security:**
• Network policies for micro-segmentation
• Pod Security Standards
• RBAC for access control
• Secrets management (not in code!)
• Regular security updates

**Best Practices:**
• Shift-left security testing
• Principle of least privilege
• Regular security audits
• Automated compliance checks
• Incident response planning

**Tools:**
• **SAST**: SonarQube, CodeQL
• **DAST**: OWASP ZAP, Burp Suite
• **Container**: Trivy, Anchore
• **Secrets**: HashiCorp Vault, AWS Secrets Manager

What security aspect would you like to focus on?`;
  }

  // Cloud platforms
  if (lowerMessage.includes('aws') || lowerMessage.includes('azure') || lowerMessage.includes('gcp') || lowerMessage.includes('cloud')) {
    return `Cloud platforms provide the foundation for modern DevOps!

**AWS DevOps Services:**
• **Compute**: EC2, ECS, EKS, Lambda
• **CI/CD**: CodePipeline, CodeBuild, CodeDeploy
• **Monitoring**: CloudWatch, X-Ray
• **Infrastructure**: CloudFormation, CDK
• **Security**: IAM, Secrets Manager, GuardDuty

**Multi-Cloud Strategy:**
• Avoid vendor lock-in
• Use best-of-breed services
• Implement consistent tooling (Terraform)
• Consider data gravity and latency

**Cloud-Native Principles:**
• Microservices architecture
• Containerization
• Serverless where appropriate
• Auto-scaling and self-healing
• Infrastructure as Code

**Cost Optimization:**
• Right-sizing resources
• Reserved instances for predictable workloads
• Spot instances for fault-tolerant workloads
• Regular cost reviews and optimization

**Migration Strategies:**
1. **Lift and Shift**: Quick migration, minimal changes
2. **Re-platforming**: Some cloud optimization
3. **Re-architecting**: Full cloud-native redesign

Which cloud platform are you using? I can provide specific guidance for AWS, Azure, or GCP!`;
  }

  // Troubleshooting and debugging
  if (lowerMessage.includes('troubleshoot') || lowerMessage.includes('debug') || lowerMessage.includes('error') || lowerMessage.includes('problem')) {
    return `Effective troubleshooting is a core DevOps skill! Here's a systematic approach:

**Troubleshooting Methodology:**
1. **Gather Information**: What changed? When did it start?
2. **Reproduce**: Can you consistently reproduce the issue?
3. **Isolate**: Narrow down the scope (service, component, environment)
4. **Hypothesize**: Form theories about root cause
5. **Test**: Validate hypotheses systematically
6. **Fix**: Implement solution and verify
7. **Document**: Record findings for future reference

**Common Investigation Areas:**
• **Logs**: Application, system, and infrastructure logs
• **Metrics**: Performance and resource utilization
• **Network**: Connectivity, DNS, load balancing
• **Dependencies**: External services, databases
• **Configuration**: Environment variables, secrets

**Useful Commands:**
\`\`\`bash
# System resources
top, htop, iostat, netstat

# Kubernetes debugging
kubectl logs <pod-name>
kubectl describe pod <pod-name>
kubectl exec -it <pod-name> -- /bin/bash

# Docker debugging
docker logs <container-id>
docker exec -it <container-id> /bin/bash
docker stats

# Network debugging
curl -v <endpoint>
nslookup <domain>
telnet <host> <port>
\`\`\`

**Prevention Strategies:**
• Comprehensive monitoring and alerting
• Health checks and circuit breakers
• Chaos engineering and fault injection
• Regular disaster recovery testing
• Proper logging and observability

What specific issue are you troubleshooting? I can provide targeted guidance!`;
  }

  // Default response for general questions
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('help')) {
    return `Hello! I'm your DevOps expert assistant. I can help you with:

🐳 **Containerization**: Docker, Kubernetes, container orchestration
🚀 **CI/CD**: Pipeline design, automation, deployment strategies  
🏗️ **Infrastructure**: Terraform, CloudFormation, Infrastructure as Code
📊 **Monitoring**: Prometheus, Grafana, observability best practices
🔒 **Security**: DevSecOps, container security, compliance
☁️ **Cloud Platforms**: AWS, Azure, GCP services and best practices
🔧 **Troubleshooting**: Debugging, performance optimization, incident response

**Popular Topics:**
• Setting up CI/CD pipelines
• Kubernetes deployment strategies
• Infrastructure automation with Terraform
• Monitoring and alerting setup
• Container security best practices
• Cloud migration strategies

What DevOps challenge can I help you solve today? Just ask about any specific tool, process, or problem you're facing!`;
  }

  // Fallback for unrecognized queries
  return `I'm here to help with your DevOps questions! I specialize in:

• **Containerization & Orchestration** (Docker, Kubernetes)
• **CI/CD Pipelines** (Jenkins, GitHub Actions, GitLab CI)
• **Infrastructure as Code** (Terraform, CloudFormation)
• **Cloud Platforms** (AWS, Azure, GCP)
• **Monitoring & Observability** (Prometheus, Grafana, ELK)
• **Security & Compliance** (DevSecOps practices)
• **Troubleshooting & Performance** (Debugging, optimization)

Could you be more specific about what you'd like help with? For example:
- "How do I set up a CI/CD pipeline?"
- "What's the best way to deploy to Kubernetes?"
- "Help me with Docker container optimization"
- "How do I monitor my applications?"

I'm ready to provide detailed, practical guidance for your DevOps challenges!`;
}