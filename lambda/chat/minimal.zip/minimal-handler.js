exports.handler = async (event) => {
    console.log('Minimal handler called with event:', JSON.stringify(event));
    
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE,PATCH'
    };

    try {
        if (event.httpMethod === 'OPTIONS') {
            console.log('Handling OPTIONS request');
            return {
                statusCode: 200,
                headers: headers,
                body: JSON.stringify({ message: 'CORS preflight OK' })
            };
        }

        if (event.httpMethod === 'POST') {
            console.log('Handling POST request');
            
            let requestBody = {};
            if (event.body) {
                try {
                    requestBody = JSON.parse(event.body);
                } catch (e) {
                    console.error('Error parsing body:', e);
                    requestBody = { message: 'Invalid JSON' };
                }
            }

            const response = {
                success: true,
                response: `Hello! I received your message: "${requestBody.message || 'No message'}". I'm your DevOps assistant and I can help you with Docker, Kubernetes, CI/CD, Infrastructure as Code, monitoring, and more!`,
                sessionId: requestBody.sessionId || 'session-' + Date.now(),
                metadata: {
                    timestamp: new Date().toISOString(),
                    handler: 'minimal-handler'
                }
            };

            console.log('Returning response:', response);

            return {
                statusCode: 200,
                headers: headers,
                body: JSON.stringify(response)
            };
        }

        console.log('Method not allowed:', event.httpMethod);
        return {
            statusCode: 405,
            headers: headers,
            body: JSON.stringify({ success: false, error: 'Method not allowed' })
        };

    } catch (error) {
        console.error('Handler error:', error);
        return {
            statusCode: 500,
            headers: headers,
            body: JSON.stringify({ 
                success: false, 
                error: 'Internal server error: ' + error.message 
            })
        };
    }
};