// Simple Chat Handler - Works without AgentCore dependencies
exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE,PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  try {
    console.log('Simple chat handler called:', JSON.stringify(event, null, 2));

    // Handle CORS preflight
    if (event.httpMethod === 'OPTIONS') {
      console.log('Handling OPTIONS preflight request');
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: 'CORS preflight successful' })
      };
    }

    if (event.httpMethod === 'POST') {
      if (!event.body) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            success: false,
            error: 'Request body is required'
          }),
        };
      }

      const request = JSON.parse(event.body);
      console.log('Parsed request:', request);

      if (!request.message) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({
            success: false,
            error: 'Message is required'
          }),
        };
      }

      // Generate session ID if not provided
      const sessionId = request.sessionId || `session-${Date.now()}`;
      
      console.log('Processing message:', request.message.substring(0, 100));

      // Simple mock response for DevOps questions
      const mockResponses = [
        "I'm your DevOps assistant! I can help you with Docker, Kubernetes, CI/CD pipelines, infrastructure as code, monitoring, and more. What specific DevOps challenge are you facing?",
        "Great question! For containerization, I'd recommend starting with Docker for packaging your applications, then moving to Kubernetes for orchestration. Would you like me to explain the basics of either?",
        "For CI/CD pipelines, popular tools include Jenkins, GitLab CI, GitHub Actions, and AWS CodePipeline. Each has its strengths depending on your infrastructure. What's your current setup?",
        "Infrastructure as Code is essential for modern DevOps. Tools like Terraform, CloudFormation, and Pulumi can help you manage infrastructure declaratively. Are you looking to get started with IaC?",
        "Monitoring and observability are crucial! Consider tools like Prometheus + Grafana for metrics, ELK stack for logs, and Jaeger for distributed tracing. What aspect of monitoring interests you most?"
      ];

      // Simple response based on message content
      let response = mockResponses[0]; // default
      
      if (request.message.toLowerCase().includes('docker') || request.message.toLowerCase().includes('container')) {
        response = mockResponses[1];
      } else if (request.message.toLowerCase().includes('ci/cd') || request.message.toLowerCase().includes('pipeline')) {
        response = mockResponses[2];
      } else if (request.message.toLowerCase().includes('terraform') || request.message.toLowerCase().includes('infrastructure')) {
        response = mockResponses[3];
      } else if (request.message.toLowerCase().includes('monitor') || request.message.toLowerCase().includes('observ')) {
        response = mockResponses[4];
      }

      const chatResponse = {
        success: true,
        response: response,
        sessionId: sessionId,
        metadata: {
          responseTime: Date.now(),
          agentId: 'simple-devops-agent',
          region: 'us-east-1',
          messageCount: 1,
          memoryEnabled: false,
          mode: 'demo'
        }
      };

      console.log('Returning response:', {
        success: chatResponse.success,
        responseLength: chatResponse.response.length,
        sessionId: chatResponse.sessionId
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(chatResponse),
      };
    }

    // Handle other HTTP methods
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Method not allowed'
      }),
    };

  } catch (error) {
    console.error('Chat handler error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Internal server error: ' + error.message
      }),
    };
  }
};