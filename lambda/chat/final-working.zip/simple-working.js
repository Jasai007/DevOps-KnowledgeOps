exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token,X-Requested-With',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE,PATCH'
  };

  try {
    console.log('Simple handler called');

    if (event.httpMethod === 'OPTIONS') {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ message: 'CORS OK' })
      };
    }

    if (event.httpMethod === 'POST') {
      const request = JSON.parse(event.body || '{}');
      
      const response = {
        success: true,
        response: `Hello! I'm your DevOps assistant. You asked: "${request.message}". I can help you with Docker, Kubernetes, CI/CD pipelines, Infrastructure as Code, monitoring, security, and troubleshooting. What specific DevOps challenge would you like help with?`,
        sessionId: request.sessionId || 'session-' + Date.now(),
        metadata: {
          responseTime: Date.now(),
          agentId: 'simple-devops-agent',
          region: 'us-east-1'
        }
      };

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(response)
      };
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ success: false, error: 'Method not allowed' })
    };

  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, error: error.message })
    };
  }
};